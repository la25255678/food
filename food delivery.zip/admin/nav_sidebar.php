 <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a href="product.php"><i class="fa fa-gear"></i> Add Products</a>
                    </li>
					<li>
                        <a href="contact.php"><i class="fa fa-envelope"></i>View Contacts</a>
                    </li>
                    <li>
                        <a href="orders.php"><i class="fa fa-truck"></i> View Order</a>
                    </li>
                    <li>
                        <a href="register.php"><i class="fa fa-truck"></i> View Register</a>
                    </li>
					<li>
                        <a href="logout.php"><i class="fa fa-user"></i> Log out </a>
                    </li>


               
                 
                </ul>

            </div>

        </nav>